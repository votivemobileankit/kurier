import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:kurier/constants/constants.dart';
import 'package:kurier/constants/rounded_button.dart';
import 'package:kurier/session/SecureStorage.dart';
import 'package:kurier/view/home/AddParcelList.dart';
import 'package:kurier/view/parcel/ParcelListActivity.dart';
import 'package:progress_hud/progress_hud.dart';

class ListApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      //title: 'Flutter Demo',
      /*theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),*/
      home: MyListPage(),
    );
  }
}

class MyListPage extends StatefulWidget {
  @override
  _MyListPageState createState() => _MyListPageState();
}

class _MyListPageState extends State<MyListPage> {
  ScrollController controller = ScrollController();
  final SecureStorage secureStorage = SecureStorage();
  bool closeTopContainer = false;
  double topContainer = 0;
  List<Widget> itemsData = [];
  String driver_id;
  String Buttontext;

  ProgressHUD _progressHUD;
  bool _loading = true;

  void getPostsData(String driverid) async {
    var APIURL =
        Uri.parse('https://votivetech.in/courier/webservice/api/getTripList');
    Map mapeddate = {"driver_id": driverid};
    print(driverid);
    Response response = await post(APIURL, body: mapeddate);
    var data = jsonDecode(response.body);
    int status = data['status'];
    print("status====: ${status}");

    if (status == "0") {
      Buttontext = "No Trip For You ";
    } else {
      dismissProgressHUD();
    }
    List data1 = data['data'];
    print("DATA: ${data1}");
    List<dynamic> responseList = data1;
    List<Widget> listItems = [];
    responseList.forEach((post) {
      listItems.add(Container(
          height: 150,
          margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(20.0)),
              color: Colors.white,
              boxShadow: [
                BoxShadow(color: Colors.black.withAlpha(100), blurRadius: 10.0),
              ]),
          child: InkWell(
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Flexible(
                          fit: FlexFit.loose,
                          child: Text(
                            post["name"],
                            softWrap: false,
                            overflow: TextOverflow.fade,
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold),
                          )),
                      Flexible(
                          fit: FlexFit.loose,
                          child: Text(
                            post["brand"],
                            softWrap: false,
                            overflow: TextOverflow.fade,
                            style: const TextStyle(
                                fontSize: 14, color: Colors.grey),
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      RaisedButton(
                        child: new Text("Add Parcel"),
                        textColor: Colors.white,
                        color: Colors.blue,
                        onPressed: () {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => AddParcelList(
                                      tripid: post["trip_id"],
                                      driver_id: post["driver_id"])));

                          /*   Navigator.of(context).push(
                              MaterialPageRoute<Null>(builder: (BuildContext context) {
                                return new AddParcelList(
                                    tripid: post["trip_id"], driver_id: post["driver_id"]);
                              }));*/
                        },
                        shape: new RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(20.0)),
                      ),
                      /* RaisedButton(
                      child: new Text("Reject"),
                      textColor: Colors.white,
                      color: Colors.red,
                      onPressed: () {
                      },
                      shape: new RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular(20.0)),
                    ),*/
                    ],
                  ),
                  Image.network(
                    post["image"],
                    fit: BoxFit.scaleDown,
                    height: double.infinity,
                    width: 180,
                  ),

                  /*Image.asset(
                  "assets/images/${post["image"]}",
                  height: double.infinity,
                )*/
                ],
              ),
            ),
            onTap: () => {
              Navigator.of(context).push(
                  MaterialPageRoute<Null>(builder: (BuildContext context) {
                return new MyParcelListPage(
                    tripid: post["trip_id"], driver_id: post["driver_id"]);
              }))
            },
          )));
    });
    setState(() {
      itemsData = listItems;
    });
  }

  @override
  void initState() {
    secureStorage.readSecureData("driverid").then((value) {
      driver_id = value;
      getPostsData(driver_id);
    });
    controller.addListener(() {
      double value = controller.offset / 119;
      setState(() {
        topContainer = value;
        closeTopContainer = controller.offset > 50;
      });
    });

    _progressHUD = new ProgressHUD(
      backgroundColor: Colors.black12,
      color: Colors.white,
      containerColor: Colors.blue,
      borderRadius: 5.0,
      text: 'Loading...',
    );

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    //final double categoryHeight = size.height*0.30;
    return WillPopScope(
      onWillPop: _onBackPressed,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
          children: <Widget>[
            AnimatedOpacity(
              duration: const Duration(milliseconds: 100),
              opacity: closeTopContainer ? 0 : 1,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 100),
                width: size.width,
                alignment: Alignment.topLeft,
                //height: closeTopContainer?0:categoryHeight,
                //child: categoriesScroller
              ),
            ),
            Expanded(
                child: ListView.builder(
                    controller: controller,
                    itemCount: itemsData.length,
                    physics: BouncingScrollPhysics(),
                    itemBuilder: (context, index) {
                      double scale = 1.0;
                      if (topContainer > 0.5) {
                        scale = index + 0.5 - topContainer;
                        if (scale < 0) {
                          scale = 0;
                        } else if (scale > 1) {
                          scale = 1;
                        }
                      }
                      return Opacity(
                        opacity: scale,
                        child: Transform(
                          transform: Matrix4.identity()..scale(scale, scale),
                          alignment: Alignment.bottomCenter,
                          child: Align(
                              heightFactor: 0.8,
                              alignment: Alignment.topCenter,
                              child: itemsData[index]),
                        ),
                      );
                    })),
            _progressHUD,
          ],
        ),
      ),
    );
  }

  void dismissProgressHUD() {
    setState(() {
      if (_loading) {
        _progressHUD.state.dismiss();
      } else {
        _progressHUD.state.show();
      }

      _loading = !_loading;
    });
  }

  Future<bool> _onBackPressed() {
    return showDialog(
          context: context,
          builder: (context) => new AlertDialog(
            title: new Text('Are you sure?'),
            content: new Text('Do you want to exit an App'),
            actions: <Widget>[
              new GestureDetector(
                onTap: () => Navigator.of(context).pop(false),
                child: roundedButton(
                    "No", const Color(0xFF167F67), const Color(0xFFFFFFFF)),
              ),
              new GestureDetector(
                onTap: () => Navigator.of(context).pop(true),
                child: roundedButton(
                    " Yes ", const Color(0xFF167F67), const Color(0xFFFFFFFF)),
              ),
            ],
          ),
        ) ??
        false;
  }

  Widget roundedButton(String buttonLabel, Color bgColor, Color textColor) {
    var loginBtn = new Container(
      padding: EdgeInsets.all(5.0),
      alignment: FractionalOffset.center,
      decoration: new BoxDecoration(
        color: bgColor,
        borderRadius: new BorderRadius.all(const Radius.circular(10.0)),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: const Color(0xFF696969),
            offset: Offset(1.0, 6.0),
            blurRadius: 0.001,
          ),
        ],
      ),
      child: Text(
        buttonLabel,
        style: new TextStyle(
            color: textColor, fontSize: 20.0, fontWeight: FontWeight.bold),
      ),
    );
    return loginBtn;
  }
}
