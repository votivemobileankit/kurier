import 'package:flutter/material.dart';
import 'dart:io';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart' as pPath;
import 'package:provider/provider.dart';

class UploadImageDemo extends StatefulWidget {
  final String title = "Upload Image Demo";

  /* String parcelid;
 UploadImageDemo(this.parcelid);
*/

  @override
  UploadImageDemoState createState() => UploadImageDemoState();
}

class UploadImageDemoState extends State<UploadImageDemo> {
  //
  static final String uploadEndPoint = 'https://votivetech.in/courier/webservice/api/uploadFile';

  Future<File> file;
  String status = '';
  String imageType;
  String errMessage = 'Error Uploading Image';

/*  chooseImage() {
    setState(() {
      file = ImagePicker.pickImage(source: ImageSource.gallery);
      print("selected image>>>>>>: ${file}");
    });
    setStatus('');
  }*/

  File _takenImage;

  Future<void> _takePicture() async {
    final imageFile = await ImagePicker.pickImage(
      source: ImageSource.gallery,
    );

    file = ImagePicker.pickImage(source: ImageSource.gallery);
    if (imageFile == null) {
      return;
    }

    print("file>>>>>>: ${file}");
    setState(() {
      _takenImage = imageFile;
    });
    final appDir = await pPath.getApplicationDocumentsDirectory();
    final fileName = path.basename(imageFile.path);
    final savedImage = await imageFile.copy('${appDir.path}/$fileName');

    var _imageToStore = Picture(picName: savedImage);
    _storeImage() {
      Provider.of<Pictures>(context, listen: false).storeImage(_imageToStore);
    }

    print("savedImage---: ${savedImage}");
    print("imageFile.path---: ${imageFile.path}");
    _storeImage();
    setStatus('');
  }

  setStatus(String message) {
    setState(() {
      status = message;
      print("message>>>>>>: ${message}");
    });
  }

  startUpload() {
    print("Uploading Image...'}");
    setStatus('Uploading Image...');
    if (null == _takenImage) {
      setStatus(errMessage);
      return;
    }
    String fileName = _takenImage.path.split('/').last;
    print("tmpFile.path>>>>>>: ${fileName}");
    postMultipartImage(fileName);
  }

/*
  upload(String fileName) {


    http.post(uploadEndPoint, body: {
      "image": base64Image,
      "name": fileName,
      "parcel_id": "1",
      "note": "note",
    }).then((result) {
      print("result>>>..'${result}");
      setStatus(result.statusCode == 200 ? result.body : errMessage);
    }).catchError((error) {
      setStatus(error);
      print("Uploading Image...'${error}");
    });
  }
*/

/*  Future upload(String fileName) async {
    var APIURL = Uri.parse(
        'https://votivetech.in/courier/webservice/api/parcelDelivered');
    Map mapeddate = {
      "parcel_id": "321",
      "image": imageType,
      "name": fileName,
      "note": "note",
    };
    Response response = await post(APIURL, body: mapeddate);
    var data = jsonDecode(response.body);
    print("response: ${response}");
    print("DispatchParcel: ${data}");
    print("mapeddate: ${mapeddate}");
    int status = data['status'];
    print("DispatchParcel: ${status}");
    if (status == 1) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => GroceryHomePage()));
    } else {
      Fluttertoast.showToast(
          msg: " Already Dispate",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          //    timeInSecForIos: 1,
          backgroundColor: Color(0xff2199c7),
          textColor: Colors.red,
          fontSize: 16.0);
    }



  }*/

  Future<dynamic> postMultipartImage(String filePath) async {
    print("filePath>>>>>>:${filePath}");
    var responseJson;
    try {
      var request = http.MultipartRequest(
          'POST',
          Uri.parse(
              "https://votivetech.in/courier/webservice/api/parcelDelivered"));

      request.files.add(await http.MultipartFile.fromPath('image', filePath));
      print(request.headers);
      request.fields['parcel_id'] = '321';
      request.fields['note'] = 'note';
      final streamedResponse = await request.send();
      print("filePath>>>>>>:${streamedResponse}");
      final response = await http.Response.fromStream(streamedResponse)
          .timeout(Duration(seconds: 90), onTimeout: () {
        print("postMultipartImage>>>>>>:");
      });

      print("postMultipartImage>>>>>>: ${response.body}");
      responseJson = await _response(response);
    } on SocketException {}
    return responseJson;
  }

  dynamic _response(http.BaseResponse response) async {
    String responsePhrase = response is http.Response
        ? response.body
        : response is http.StreamedResponse
            ? await response.stream.bytesToString()
            : null;
    switch (response.statusCode) {
      case 200:
        var responseJson = json.decode(responsePhrase);
        // aPrint(responseJson);
        return responseJson;
      case 400:

      case 401:

      case 403:

      case 500:
      case 204:
        var responseJson = "";
        if (responsePhrase == "") {
          responseJson = "[]";
        } else {
          responseJson = json.decode(responsePhrase);
        }
        // aPrint(responseJson);
        return responseJson;
      case 201:
        var responseJson = json.decode(responsePhrase);
        //  aPrint(responseJson);
        return responseJson;
      case 409:
        var responseJson = json.decode(responsePhrase);
        //  aPrint(responseJson);
        return responseJson;
    }
  }

  Widget showImage() {
    return FutureBuilder<File>(
      future: file,
      builder: (BuildContext context, AsyncSnapshot<File> snapshot) {
        if (snapshot.connectionState == ConnectionState.done &&
            null != snapshot.data) {
          _takenImage = snapshot.data;
          imageType = base64Encode(snapshot.data.readAsBytesSync());
          return Flexible(
            child: Image.file(
              snapshot.data,
              fit: BoxFit.fill,
            ),
          );
        } else if (null != snapshot.error) {
          return const Text(
            'Error Picking Image',
            textAlign: TextAlign.center,
          );
        } else {
          return const Text(
            'No Image Selected',
            textAlign: TextAlign.center,
          );
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Upload Image Demo"),
      ),
      body: Container(
        padding: EdgeInsets.all(30.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            OutlineButton(
              onPressed: _takePicture,
              child: Text('Choose Image'),
            ),
            SizedBox(
              height: 20.0,
            ),
            showImage(),
            SizedBox(
              height: 20.0,
            ),
            OutlineButton(
              onPressed: startUpload,
              child: Text('Upload Image'),
            ),
            SizedBox(
              height: 20.0,
            ),
            Text(
              status,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.green,
                fontWeight: FontWeight.w500,
                fontSize: 20.0,
              ),
            ),
            SizedBox(
              height: 20.0,
            ),
          ],
        ),
      ),
    );
  }
}

class Pictures with ChangeNotifier {
  List<Picture> _items = [];

  List<Picture> get items {
    return [..._items];
  }

  storeImage(Picture pickedImage) {
    final newImage = Picture(
      picName: pickedImage.picName,
    );
    _items.add(newImage);
    notifyListeners();
  }
}

class Picture with ChangeNotifier {
  final File picName;

  Picture({
    @required this.picName,
  });
}
