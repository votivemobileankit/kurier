import 'dart:async';

import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:kurier/session/SecureStorage.dart';

import 'AddTripList.dart';

class RestaurantList extends StatefulWidget {
  @override
  _HomePageState createState() => new _HomePageState();
}

class _HomePageState extends State<RestaurantList> {
  TextEditingController controller = new TextEditingController();
  final SecureStorage secureStorage = SecureStorage();

  // Get json result and convert it to model. Then add
  Future<Null> getUserDetails() async {
    _userDetails.clear();
    _searchResult.clear();
    Map mapeddate = {
      'search_key': "",
      'start_value': "1",
    };
    print("mapeddate: ${mapeddate}");
    print("url>>: ${url}");

    final response = await http.post(url, body: mapeddate);
    final responseJson = json.decode(response.body);

    List data1 = responseJson['data'];
    print("DATA: ${data1}");
    List<dynamic> responseList = data1;
    print("responseJson>>: ${data1}");
    setState(() {
      for (Map user in data1) {
        _userDetails.add(UserDetails.fromJson(user));
      }
    });
  }

  @override
  void initState() {
    super.initState();

    getUserDetails();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text('Connect with restaurant'),
        elevation: 0.0,
      ),
      body: new Column(
        children: <Widget>[
          new Container(
            color: Theme.of(context).primaryColor,
            child: new Padding(
              padding: const EdgeInsets.all(8.0),
              child: new Card(
                child: new ListTile(
                  leading: new Icon(Icons.search),
                  title: new TextField(
                    controller: controller,
                    decoration: new InputDecoration(
                        hintText: 'Search', border: InputBorder.none),
                    onChanged: onSearchTextChanged,
                  ),
                  trailing: new IconButton(
                    icon: new Icon(Icons.cancel),
                    onPressed: () {
                      controller.clear();
                      onSearchTextChanged('');
                    },
                  ),
                ),
              ),
            ),
          ),
          new Expanded(
            child: _searchResult.length != 0 || controller.text.isNotEmpty
                ? new ListView.builder(
                    itemCount: _searchResult.length,
                    itemBuilder: (context, i) {
                      return new Card(
                        child: new ListTile(
                          leading: new CircleAvatar(
                            backgroundImage: new NetworkImage(
                              _searchResult[i].restaurant_image,
                            ),
                          ),
                          title: new Text(_searchResult[i].restaurant_name),
                          subtitle: Text('${_searchResult[i].street_address}'),
                          onTap:
                          () {
                            secureStorage.writeSecureData('restaurant_id',
                                _searchResult[i].restaurant_id);
                            Navigator.of(context).push(MaterialPageRoute<Null>(
                                builder: (BuildContext context) {
                              return new AddTripList();
                            }));
                          },

                        ),
                        margin: const EdgeInsets.all(0.0),
                      );
                    },
                  )
                : new ListView.builder(
                    itemCount: _userDetails.length,
                    itemBuilder: (context, index) {
                      return new Card(
                        child: new ListTile(
                          leading: new CircleAvatar(
                            backgroundImage: new NetworkImage(
                              _userDetails[index].restaurant_image,
                            ),
                          ),
                          title: new Text(_userDetails[index].restaurant_name),
                          subtitle:
                              Text('${_userDetails[index].street_address}'),
                          onTap: () {
                            secureStorage.writeSecureData('restaurant_id',
                                _userDetails[index].restaurant_id);
                            Navigator.of(context).push(MaterialPageRoute<Null>(
                                builder: (BuildContext context) {
                              return new AddTripList();
                            }));
                          },
                        ),
                        margin: const EdgeInsets.all(0.0),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

/*  _showDialog() async {
    await showDialog<String>(
      context: context,
      child: new _SystemPadding(
        child: new AlertDialog(
          contentPadding: const EdgeInsets.all(16.0),
          content: new Row(
            children: <Widget>[
              new Expanded(
                child: new TextField(
                  autofocus: true,
                  decoration: new InputDecoration(
                      labelText: '', hintText: ''),
                ),
              )
            ],
          ),
          actions: <Widget>[
            new FlatButton(
                child: const Text('CANCEL'),
                onPressed: () {
                  Navigator.pop(context);
                }),
            new FlatButton(
                child: const Text('OPEN'),
                onPressed: () {
                  Navigator.pop(context);
                })
          ],
        ),
      ),
    );
  }*/

  onSearchTextChanged(String text) async {
    _searchResult.clear();
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    _userDetails.forEach((userDetail) {
      if (userDetail.first_name.contains(text) ||
          userDetail.surname.contains(text)) _searchResult.add(userDetail);
    });

    setState(() {});
  }
}

List<UserDetails> _searchResult = [];

List<UserDetails> _userDetails = [];

final String url =
    'https://votivetech.in/courier/webservice/api/getAllRestaurantList';

class UserDetails {
  final String restaurant_id, first_name, surname, restaurant_name;
  final String mobile_number, email, street_address, restaurant_image;

  UserDetails(
      {this.restaurant_id,
      this.first_name,
      this.surname,
      this.restaurant_name,
      this.mobile_number,
      this.email,
      this.street_address,
      this.restaurant_image});

  factory UserDetails.fromJson(Map<String, dynamic> json) {
    return new UserDetails(
      restaurant_id: json['restaurant_id'],
      first_name: json['first_name'],
      surname: json['surname'],
      restaurant_name: json['restaurant_name'],
      mobile_number: json['mobile_number'],
      email: json['email'],
      street_address: json['address'],
      restaurant_image: json['restaurant_image'],
    );
  }
}
class _SystemPadding extends StatelessWidget {
  final Widget child;

  _SystemPadding({Key key, this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var mediaQuery = MediaQuery.of(context);
    return new AnimatedContainer(
        padding: mediaQuery.viewInsets,
        duration: const Duration(milliseconds: 300),
        child: child);
  }
}