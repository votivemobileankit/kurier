import 'package:flutter/material.dart';

Color orangeColors = Color(0xFF075C7D);
Color orangeLightColors = Color(0xFF78CCED);
const kPrimaryColor = Color(0xFF075C7D);
const kPrimaryLightColor = Color(0xFF78CCED);