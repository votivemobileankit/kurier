const FOOD_DATA = [
  {
    "name":"Trip 1",
    "brand":"Hawkers",
    "image":"burger.png"
  },{
    "name":"Trip 2",
    "brand":"Hawkers",
    "image":"cheese_dip.png"
  },
  {
    "name":"Trip 3",
    "brand":"Mcdonald",
    "image":"cola.png"
  },
  {
    "name":"Trip 4",
    "brand":"Mcdonald",
    "image":"fries.png"
  },
  {
    "name":"Trip 5",
    "brand":"Ben & Jerry's",
    "image":"ice_cream.png"
  },
  {
    "name":"Trip 6",
    "brand":"Hawkers",
    "image":"noodles.png"
  },
  {
    "name":"Trip 7",
    "brand":"Dominos",
    "image":"pizza.png"
  },
  {
    "name":"Trip 8",
    "brand":"Hawkers",
    "image":"sandwich.png"
  },
  {
    "name":"Trip 9",
    "brand":"Subway",
    "image":"wrap.png"
  }
];